// Asia Parts Search V6 — Staff / Owner Mode
const SHEET_PARTS = "Parts";
const SHEET_USERS = "Users";
const OWNER_ONLY_COLUMNS = ["ราคาทุน","ราคาขาย","ราคา","กำไร","ซัพพลายเออร์","Supplier","supplier","หมายเหตุเจ้าของ","หมายเหตุลับ","ต้นทุน"];

function doGet(e) {
  try {
    const token = String(e.parameter.token || "").trim();
    const auth = checkToken_(token);
    if (!auth.ok) return json_({ ok:false, error:"รหัสนี้ไม่มีสิทธิ์ใช้งาน หรือถูกปิดสิทธิ์แล้ว" });
    const result = getPartsData_(auth.role);
    return json_({ ok:true, employee:auth.name, role:auth.role, headers:result.headers, rows:result.rows });
  } catch (err) {
    return json_({ ok:false, error:String(err) });
  }
}

function checkToken_(token) {
  if (!token) return { ok:false };
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_USERS);
  if (!sh) throw new Error("ไม่พบชีต Users");
  const values = sh.getDataRange().getDisplayValues();
  if (values.length < 2) return { ok:false };
  const headers = values[0].map(h => String(h).trim());
  const tokenCol = headers.indexOf("token");
  const nameCol = headers.indexOf("name");
  const roleCol = headers.indexOf("role");
  const activeCol = headers.indexOf("active");
  if (tokenCol < 0 || activeCol < 0 || roleCol < 0) throw new Error("ชีต Users ต้องมีหัวตาราง token, role, active");
  for (let i = 1; i < values.length; i++) {
    const rowToken = String(values[i][tokenCol]).trim();
    const active = String(values[i][activeCol]).trim().toUpperCase();
    if (rowToken === token && (active === "TRUE" || active === "YES" || active === "1" || active === "เปิด")) {
      return { ok:true, name:nameCol >= 0 ? String(values[i][nameCol]).trim() : "พนักงาน", role:String(values[i][roleCol] || "staff").trim().toLowerCase() };
    }
  }
  return { ok:false };
}

function getPartsData_(role) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_PARTS) || ss.getSheets()[0];
  const values = sh.getDataRange().getDisplayValues();
  if (values.length < 2) return { headers:[], rows:[] };
  const rawHeaders = values[0].map(h => String(h).trim()).filter(h => h);
  const visibleHeaders = rawHeaders.filter(h => canSeeColumn_(role, h));
  const rows = [];
  for (let i = 1; i < values.length; i++) {
    const obj = {}; let hasData = false;
    for (let j = 0; j < rawHeaders.length; j++) {
      const h = rawHeaders[j];
      if (!h || !canSeeColumn_(role, h)) continue;
      const v = String(values[i][j] || "").trim();
      obj[h] = v;
      if (v) hasData = true;
    }
    if (hasData) rows.push(obj);
  }
  return { headers:visibleHeaders, rows };
}

function canSeeColumn_(role, header) {
  const r = String(role || "staff").toLowerCase();
  if (r === "owner" || r === "admin") return true;
  return OWNER_ONLY_COLUMNS.map(normalize_).indexOf(normalize_(header)) === -1;
}
function normalize_(s) { return String(s || "").toLowerCase().replace(/\s+/g, ""); }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
