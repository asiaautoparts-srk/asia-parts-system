Asia Parts Search V6 — Staff / Owner Mode

ฟังก์ชันในเวอร์ชันนี้:
- ค้นหาอะไหล่จาก Google Sheets ของร้าน
- Staff / Owner แยกสิทธิ์
- Staff ไม่เห็นราคาทุน ราคาขาย กำไร ซัพพลายเออร์ หมายเหตุเจ้าของ
- Owner เห็นทุกคอลัมน์
- ปิดสิทธิ์พนักงานลาออกได้ด้วย active = FALSE
- ไม่มีข้อมูลตัวอย่างซ่อนในเว็บ
- ถ้าไม่มีข้อมูลในชีต ระบบไม่เดา
- ตัดเรื่องจำนวนสต๊อกออกก่อนตามที่ตกลงกัน

Google Sheets ต้องมี:

ชีต Parts
หัวตารางแนะนำ:
สินค้า | ตำแหน่ง | รุ่นรถ | หมายเหตุ | รูป | ราคาทุน | ราคาขาย | ซัพพลายเออร์ | หมายเหตุเจ้าของ

ชีต Users
หัวตาราง:
token | name | role | active

ตัวอย่าง:
STAFF-A001-7K9P | ข้าว | staff | TRUE
OWNER-9K7X-22 | เจ้าของร้าน | owner | TRUE

วิธีติดตั้ง:
1. เปิด Google Sheets ของร้าน
2. Extensions > Apps Script
3. วางโค้ด apps_script.gs
4. Deploy > New deployment > Web app
5. Execute as: Me
6. Who has access: Anyone
7. Copy Web App URL
8. เปิด index.html แล้วแทน PASTE_APPS_SCRIPT_WEB_APP_URL_HERE ด้วย Web App URL
9. อัป index.html ขึ้น Netlify/GitHub
10. ส่งลิงก์ให้พนักงาน

การปิดสิทธิ์:
- เปิดชีต Users
- เปลี่ยน active เป็น FALSE
